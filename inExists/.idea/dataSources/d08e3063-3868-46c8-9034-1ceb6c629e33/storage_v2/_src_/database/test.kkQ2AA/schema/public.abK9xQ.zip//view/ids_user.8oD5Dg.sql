create view ids_user as
  SELECT user_table.id
  FROM user_table;

alter table ids_user
  owner to postgres;


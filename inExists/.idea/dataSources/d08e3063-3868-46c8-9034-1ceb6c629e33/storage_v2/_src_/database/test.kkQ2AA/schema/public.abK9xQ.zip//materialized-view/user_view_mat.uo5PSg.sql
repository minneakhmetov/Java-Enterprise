create materialized view user_view_mat as
  SELECT user_table.id, user_table.phone, user_table.password, user_table.creator
  FROM user_table
  WHERE (user_table.phone > 8000);

alter materialized view user_view_mat
  owner to postgres;


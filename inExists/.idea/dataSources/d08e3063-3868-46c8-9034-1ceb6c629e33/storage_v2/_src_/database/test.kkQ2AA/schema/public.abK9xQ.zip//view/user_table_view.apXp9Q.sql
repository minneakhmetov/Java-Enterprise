create view user_table_view as
  SELECT user_table.id, user_table.phone, user_table.password
  FROM user_table
  WHERE (((user_table.creator) :: name = CURRENT_USER) OR (CURRENT_USER = 'postgres' :: name));

alter table user_table_view
  owner to postgres;


create view user_posts as
  SELECT user_table.id AS user_table_id,
         user_table.phone,
         user_table.password,
         post_table.id AS post_table_id,
         post_table.text
  FROM (user_table
      JOIN post_table ON ((post_table.id = user_table.id)));

alter table user_posts
  owner to postgres;


create view users_table_view_idea as
  SELECT user_table.id, user_table.phone, user_table.password, user_table.creator
  FROM user_table;

alter table users_table_view_idea
  owner to postgres;


create view user_view as
  SELECT user_table.id, user_table.phone, user_table.password
  FROM user_table
  WHERE (user_table.phone > 8000);

alter table user_view
  owner to postgres;

